# Exec - wrapper package for system debug/elf package

The package allows to mock debug/elf package functions for testing purposes.
