# GPU 监控系统部署指南

## 📋 系统要求

### 硬件要求
- 支持 GPU 的服务器
- 至少 4GB RAM
- 至少 20GB 磁盘空间

### 软件要求
- Docker Engine >= 20.10
- Docker Compose >= 2.0
- NVIDIA GPU 驱动 (如果使用 NVIDIA GPU)
- NVIDIA Container Toolkit (如果使用 NVIDIA GPU)

## 🚀 快速部署

### 1. 克隆项目
```bash
git clone https://github.com/NVIDIA/dcgm-exporter.git
cd dcgm-exporter
```

### 2. 启动监控系统
```bash
# 启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f
```

### 3. 访问服务

| 服务 | 地址 | 默认账号 |
|------|------|----------|
| Grafana | http://localhost:3000 | admin/admin123 |
| Prometheus | http://localhost:9090 | - |
| DCGM Exporter | http://localhost:9400/metrics | - |
| Node Exporter | http://localhost:9100/metrics | - |
| cAdvisor | http://localhost:8080 | - |

## ⚙️ 配置说明

### Prometheus 配置
- 配置文件: `prometheus/prometheus.yml`
- 告警规则: `prometheus/rules/gpu-alerts.yml`
- 数据保留: 30天

### Grafana 配置
- 数据源: 自动配置 Prometheus
- 仪表板: 自动导入 GPU 监控仪表板
- 默认密码: admin/admin123 (首次登录后请修改)

### DCGM Exporter 配置
- 监听端口: 9400
- 指标路径: /metrics
- 收集间隔: 10秒

## 🔧 自定义配置

### 修改 GPU 指标收集
编辑 `etc/default-counters.csv` 文件：
```csv
# 添加自定义指标
DCGM_FI_DEV_NVLINK_BANDWIDTH_TOTAL, counter, NVLink bandwidth total
```

### 修改告警规则
编辑 `prometheus/rules/gpu-alerts.yml` 文件：
```yaml
# 添加自定义告警
- alert: CustomGPUAlert
  expr: your_custom_metric > threshold
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "自定义 GPU 告警"
```

### 添加新的监控目标
编辑 `prometheus/prometheus.yml` 文件：
```yaml
scrape_configs:
  - job_name: 'custom-exporter'
    static_configs:
      - targets: ['your-exporter:port']
```

## 🔄 海光卡适配指南

### 1. 替换 DCGM Exporter
如果你要适配海光卡，需要：

```yaml
# 在 docker-compose.yml 中替换 dcgm-exporter 服务
hygon-gpu-exporter:
  image: your-registry/hygon-gpu-exporter:latest
  container_name: hygon-gpu-exporter
  restart: unless-stopped
  ports:
    - "9401:9401"
  # 添加海光卡特定的配置
```

### 2. 更新 Prometheus 配置
```yaml
# 在 prometheus.yml 中添加海光卡监控
- job_name: 'hygon-gpu-exporter'
  static_configs:
    - targets: ['hygon-gpu-exporter:9401']
  scrape_interval: 10s
```

### 3. 创建海光卡仪表板
基于海光卡的指标创建新的 Grafana 仪表板。

## 🛠️ 故障排除

### 常见问题

#### 1. DCGM Exporter 启动失败
```bash
# 检查 GPU 驱动
nvidia-smi

# 检查 NVIDIA Container Toolkit
docker run --rm --gpus all nvidia/cuda:11.0-base nvidia-smi

# 查看容器日志
docker-compose logs dcgm-exporter
```

#### 2. Prometheus 无法抓取指标
```bash
# 检查网络连接
docker-compose exec prometheus wget -qO- http://dcgm-exporter:9400/metrics

# 检查 Prometheus 配置
docker-compose exec prometheus promtool check config /etc/prometheus/prometheus.yml
```

#### 3. Grafana 无法连接 Prometheus
```bash
# 检查数据源配置
docker-compose logs grafana

# 手动测试连接
docker-compose exec grafana curl http://prometheus:9090/api/v1/query?query=up
```

### 性能优化

#### 1. 调整收集间隔
```yaml
# 在 prometheus.yml 中调整
scrape_interval: 30s  # 降低频率以减少负载
```

#### 2. 配置数据保留策略
```yaml
# 在 docker-compose.yml 中调整
command:
  - '--storage.tsdb.retention.time=15d'  # 减少保留时间
```

#### 3. 限制资源使用
```yaml
# 在 docker-compose.yml 中添加资源限制
deploy:
  resources:
    limits:
      memory: 1G
      cpus: '0.5'
```

## 📊 监控最佳实践

### 1. 告警策略
- 设置合理的阈值
- 避免告警风暴
- 分级告警处理

### 2. 仪表板设计
- 关键指标优先显示
- 使用合适的图表类型
- 添加有意义的标签

### 3. 数据管理
- 定期清理历史数据
- 备份重要配置
- 监控存储使用情况

## 🔐 安全建议

### 1. 修改默认密码
```bash
# 修改 Grafana 管理员密码
docker-compose exec grafana grafana-cli admin reset-admin-password newpassword
```

### 2. 启用 HTTPS
配置反向代理（如 Nginx）来提供 HTTPS 访问。

### 3. 网络安全
- 限制端口访问
- 使用防火墙规则
- 定期更新镜像

## 📝 维护清单

### 日常维护
- [ ] 检查服务状态
- [ ] 查看告警信息
- [ ] 监控资源使用

### 周期维护
- [ ] 更新 Docker 镜像
- [ ] 备份配置文件
- [ ] 清理日志文件
- [ ] 检查磁盘空间

### 应急处理
- [ ] 服务重启流程
- [ ] 数据恢复流程
- [ ] 联系人信息

---

**注意**: 这个部署指南基于 Docker Compose，适用于单机部署。生产环境建议使用 Kubernetes 进行部署。
