# DCGM Exporter - 海光DCU支持

本项目是NVIDIA DCGM Exporter的扩展版本，增加了对海光DCU（数据中心处理器）的支持。

## 概述

海光DCU模式允许DCGM Exporter监控海光DCU设备，并将监控数据以Prometheus格式导出。该模式通过调用`hy-smi`工具获取海光DCU的监控指标。

## 支持的监控指标

海光DCU模式支持以下监控指标：

| 指标名称 | 类型 | 描述 | 单位 |
|---------|------|------|------|
| `hygon_temperature` | gauge | DCU温度 | °C |
| `hygon_avg_power` | gauge | 平均功耗 | W |
| `hygon_power_cap` | gauge | 功耗上限 | W |
| `hygon_dcu_usage` | gauge | DCU使用率 | % |
| `hygon_vram_usage` | gauge | 显存使用率 | % |
| `hygon_performance_mode` | gauge | 性能模式 (1=auto, 0=manual) | - |
| `hygon_device_mode` | gauge | 设备运行模式 (1=Normal, 0=other) | - |

## 前置条件

1. **hy-smi工具**: 确保系统中已安装并可访问`hy-smi`命令
2. **海光DCU驱动**: 确保已正确安装海光DCU驱动程序
3. **权限**: 确保运行用户有权限执行`hy-smi`命令

## 安装和配置

### 1. 验证hy-smi工具

```bash
# 检查hy-smi是否可用
hy-smi

# 应该看到类似以下的输出：
# ============================ System Management Interface =============================
# ======================================================================================
# DCU     Temp     AvgPwr     Perf     PwrCap     VRAM%      DCU%      Mode     
# 0       58.0C    259.0W     auto     400.0W     97%        34.2%     Normal   
# ...
```

### 2. 构建支持海光DCU的DCGM Exporter

```bash
# 克隆项目
git clone <repository-url>
cd dcgm-exporter

# 构建
make binary
```

### 3. 配置指标文件

海光DCU模式使用专门的指标配置文件：

```bash
# 复制海光DCU指标配置文件
cp etc/hygon-counters.csv /etc/dcgm-exporter/hygon-counters.csv
```

## 使用方法

### 命令行参数

海光DCU模式新增了以下命令行参数：

- `--use-hygon-mode`: 启用海光DCU监控模式（默认：false）
- `--hygon-devices`: 指定要监控的海光DCU设备（默认：f，监控所有设备）
- `--hy-smi-path`: 指定hy-smi命令的路径（默认：hy-smi）

### 基本使用

```bash
# 启动海光DCU模式
./dcgm-exporter --use-hygon-mode

# 指定监控特定设备
./dcgm-exporter --use-hygon-mode --hygon-devices="g:0,1,2,3"

# 指定hy-smi路径
./dcgm-exporter --use-hygon-mode --hy-smi-path="/usr/local/bin/hy-smi"

# 指定自定义指标文件
./dcgm-exporter --use-hygon-mode --collectors="/path/to/custom-hygon-counters.csv"
```

### 环境变量

也可以通过环境变量配置：

```bash
export DCGM_EXPORTER_USE_HYGON_MODE=true
export DCGM_EXPORTER_HYGON_DEVICES_STR="f"
export DCGM_EXPORTER_HY_SMI_PATH="hy-smi"
./dcgm-exporter
```

### Docker使用

```bash
# 构建Docker镜像
docker build -t dcgm-exporter-hygon .

# 运行容器（需要访问hy-smi工具）
docker run -d \
  --name dcgm-exporter-hygon \
  --privileged \
  -p 9400:9400 \
  -e DCGM_EXPORTER_USE_HYGON_MODE=true \
  dcgm-exporter-hygon
```

## Prometheus配置

在Prometheus配置文件中添加海光DCU exporter：

```yaml
scrape_configs:
  - job_name: 'hygon-dcu'
    static_configs:
      - targets: ['localhost:9400']
    scrape_interval: 30s
    metrics_path: /metrics
```

## 监控指标示例

启动后，可以通过以下URL查看指标：

```bash
curl http://localhost:9400/metrics
```

示例输出：

```
# HELP DCGM_hygon_temperature DCU temperature (in C).
# TYPE DCGM_hygon_temperature gauge
DCGM_hygon_temperature{device="0",hostname="server01",modelName="Hygon-DCU",mode="Normal",performance="auto",uuid="DCU-0"} 58.0

# HELP DCGM_hygon_avg_power Average power consumption (in W).
# TYPE DCGM_hygon_avg_power gauge
DCGM_hygon_avg_power{device="0",hostname="server01",modelName="Hygon-DCU",mode="Normal",performance="auto",uuid="DCU-0"} 259.0

# HELP DCGM_hygon_dcu_usage DCU utilization (in %).
# TYPE DCGM_hygon_dcu_usage gauge
DCGM_hygon_dcu_usage{device="0",hostname="server01",modelName="Hygon-DCU",mode="Normal",performance="auto",uuid="DCU-0"} 34.2
```

## 故障排除

### 1. hy-smi命令未找到

```bash
# 检查hy-smi是否在PATH中
which hy-smi

# 如果不在PATH中，使用完整路径
./dcgm-exporter --use-hygon-mode --hy-smi-path="/usr/local/bin/hy-smi"
```

### 2. 权限问题

```bash
# 确保用户有权限执行hy-smi
sudo chmod +x /usr/bin/hy-smi
sudo usermod -a -G hygon $USER
```

### 3. 没有检测到设备

```bash
# 检查hy-smi输出
hy-smi

# 检查海光DCU驱动状态
lsmod | grep hygon
```

### 4. 调试模式

```bash
# 启用调试模式获取更多信息
./dcgm-exporter --use-hygon-mode --debug
```

## 与NVIDIA GPU模式的区别

| 特性 | NVIDIA GPU模式 | 海光DCU模式 |
|------|---------------|------------|
| 数据源 | DCGM API | hy-smi命令 |
| 设备类型 | NVIDIA GPU | 海光DCU |
| 指标前缀 | `DCGM_FI_*` | `hygon_*` |
| 配置文件 | `default-counters.csv` | `hygon-counters.csv` |
| 依赖 | DCGM库 | hy-smi工具 |

## 贡献

欢迎提交问题和改进建议。在提交PR之前，请确保：

1. 运行所有测试：`make test`
2. 检查代码格式：`make fmt`
3. 更新相关文档

## 许可证

本项目遵循Apache 2.0许可证。详见LICENSE文件。
