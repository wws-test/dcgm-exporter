# Exec - wrapper package for system os/exec package

The package allows to mock os/exec package functions for testing purposes.
