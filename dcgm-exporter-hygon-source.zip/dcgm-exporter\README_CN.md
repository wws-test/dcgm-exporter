# DCGM-Exporter 中文指南

## 项目简介

DCGM-Exporter 是一个专门为 GPU 监控设计的 Prometheus 指标导出器，基于 NVIDIA DCGM (Data Center GPU Manager) 构建。它能够收集 GPU 的各种性能指标并以 Prometheus 格式暴露，便于监控和告警。

### 🎯 项目目标
- 收集 GPU 硬件指标（温度、功耗、利用率等）
- 以 Prometheus 格式暴露指标
- 支持 Kubernetes 环境部署
- 提供 Grafana 仪表板可视化

### 🏗️ 项目架构

```
dcgm-exporter/
├── cmd/dcgm-exporter/          # 主程序入口
├── internal/pkg/               # 内部包
│   ├── collector/              # 指标收集器
│   ├── dcgmprovider/          # DCGM 接口封装
│   ├── nvmlprovider/          # NVML 接口封装
│   └── server/                # HTTP 服务器
├── etc/                       # 配置文件
│   └── default-counters.csv   # 默认指标配置
├── docker/                    # Docker 构建文件
├── grafana/                   # Grafana 仪表板
└── deployment/                # Kubernetes 部署文件
```

## 🔧 核心组件

### 1. 指标收集器 (Collector)
- **GPU Collector**: 收集基础 GPU 指标
- **XID Collector**: 收集 GPU 错误信息
- **Clock Events Collector**: 收集时钟事件
- **Health Collector**: 收集健康状态

### 2. 数据提供者 (Provider)
- **DCGM Provider**: 通过 DCGM 库获取指标
- **NVML Provider**: 通过 NVML 库获取指标

### 3. 指标类型
默认收集的指标包括：
- **时钟频率**: SM 时钟、内存时钟
- **温度**: GPU 温度、内存温度
- **功耗**: 功耗使用量、总能耗
- **利用率**: GPU 利用率、内存利用率、编解码器利用率
- **内存**: 显存使用量、显存空闲量
- **错误**: XID 错误、PCIe 重试次数

## 🚀 快速开始

### 使用 Docker 运行

```bash
# 运行 DCGM-Exporter
docker run -d \
  --gpus all \
  --cap-add SYS_ADMIN \
  --rm \
  -p 9400:9400 \
  nvcr.io/nvidia/k8s/dcgm-exporter:4.2.3-4.2.0-ubuntu22.04

# 查看指标
curl localhost:9400/metrics
```

### 在 Kubernetes 中部署

```bash
# 使用 Helm 安装
helm repo add gpu-helm-charts https://nvidia.github.io/dcgm-exporter/helm-charts
helm repo update
helm install dcgm-exporter gpu-helm-charts/dcgm-exporter

# 或使用 YAML 文件
kubectl create -f dcgm-exporter.yaml
```

## 🛠️ 从源码构建

### 环境要求
- Go >= 1.22
- DCGM 库
- 支持 GPU 的 Linux 系统

### 构建步骤

```bash
# 克隆仓库
git clone https://github.com/NVIDIA/dcgm-exporter.git
cd dcgm-exporter

# 构建二进制文件
make binary

# 安装
sudo make install

# 运行
dcgm-exporter &
curl localhost:9400/metrics
```

## ⚙️ 配置说明

### 指标配置
通过 CSV 文件配置要收集的指标：

```csv
# 格式: DCGM字段, Prometheus指标类型, 帮助信息
DCGM_FI_DEV_SM_CLOCK, gauge, SM clock frequency (in MHz).
DCGM_FI_DEV_GPU_TEMP, gauge, GPU temperature (in C).
```

### 命令行参数
- `-f, --collectors`: 指定自定义指标配置文件
- `--address`: 监听地址 (默认: :9400)
- `--collect-interval`: 收集间隔
- `--devices`: 指定监控的设备
- `--kubernetes`: 启用 Kubernetes 模式

## 🎨 Grafana 仪表板

项目提供了官方 Grafana 仪表板：
- 仪表板 ID: 12239
- 本地文件: `grafana/dcgm-exporter-dashboard.json`

## 🔄 适配海光卡的改造思路

为了适配国产海光卡，你需要关注以下几个关键点：

### 1. 硬件抽象层
- 替换 DCGM/NVML 接口为海光卡的 SDK
- 修改 `internal/pkg/dcgmprovider/` 和 `internal/pkg/nvmlprovider/`

### 2. 指标映射
- 分析海光卡支持的指标类型
- 修改 `etc/default-counters.csv` 配置
- 更新指标收集逻辑

### 3. 设备识别
- 修改设备发现和识别逻辑
- 更新 `internal/pkg/deviceinfo/` 相关代码

### 4. 构建系统
- 修改 Dockerfile 以支持海光卡驱动
- 更新依赖库和编译选项

## 📊 监控指标示例

```
# GPU 利用率
DCGM_FI_DEV_GPU_UTIL{gpu="0", UUID="GPU-xxx"} 85.0

# GPU 温度
DCGM_FI_DEV_GPU_TEMP{gpu="0", UUID="GPU-xxx"} 65.0

# 功耗
DCGM_FI_DEV_POWER_USAGE{gpu="0", UUID="GPU-xxx"} 250.5

# 显存使用
DCGM_FI_DEV_FB_USED{gpu="0", UUID="GPU-xxx"} 8192.0
```

## 🔐 安全配置

支持 TLS 和基础认证：

```bash
dcgm-exporter --web-config-file=web-config.yaml
```

## 🤝 贡献指南

1. Fork 项目
2. 创建特性分支
3. 提交更改
4. 创建 Pull Request

## 📝 许可证

本项目采用 Apache License 2.0 许可证。

## 🆘 故障排除

### 常见问题
1. **权限问题**: 确保有足够权限访问 GPU
2. **驱动问题**: 确保安装了正确的 GPU 驱动
3. **DCGM 问题**: 确保 DCGM 服务正常运行

### 调试模式
```bash
dcgm-exporter --debug
```

---

**注意**: 这是 NVIDIA DCGM-Exporter 的中文说明文档，用于帮助理解项目结构和改造思路。
