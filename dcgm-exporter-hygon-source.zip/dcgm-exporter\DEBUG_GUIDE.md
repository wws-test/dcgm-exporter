# 海光DCU DCGM Exporter 调试指南

## 🔧 调试环境准备

### 1. 检查系统环境

```bash
# 检查操作系统
uname -a

# 检查Go版本
go version

# 检查Git
git --version

# 检查海光DCU驱动
lsmod | grep hygon
```

### 2. 检查海光DCU工具

```bash
# 检查hy-smi是否安装
which hy-smi

# 测试hy-smi命令
hy-smi

# 检查hy-smi帮助
hy-smi --help

# 检查权限
ls -la $(which hy-smi)
```

## 🚀 构建和部署

### 1. 在Linux服务器上构建

```bash
# 1. 上传源码到Linux服务器
scp -r dcgm-exporter/ user@server:/path/to/

# 2. 登录服务器
ssh user@server

# 3. 进入项目目录
cd /path/to/dcgm-exporter

# 4. 运行构建脚本
chmod +x build-for-linux.sh
./build-for-linux.sh

# 5. 检查构建结果
ls -la bin/
ls -la packages/
```

### 2. 快速测试构建

```bash
# 如果构建脚本失败，可以手动构建
go mod tidy
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o dcgm-exporter-hygon ./cmd/dcgm-exporter
```

## 🐛 调试步骤

### 1. 基础功能测试

```bash
# 检查二进制文件
./dcgm-exporter-hygon --help

# 测试海光DCU模式启动
./dcgm-exporter-hygon --use-hygon-mode --debug

# 测试NVIDIA GPU模式启动
./dcgm-exporter-hygon --debug
```

### 2. 海光DCU模式调试

```bash
# 启用详细调试
./dcgm-exporter-hygon \
    --use-hygon-mode \
    --debug \
    --collectors="./etc/hygon-counters.csv" \
    --address=":9400"

# 在另一个终端检查指标
curl http://localhost:9400/metrics

# 检查健康状态
curl http://localhost:9400/health

# 过滤海光DCU指标
curl http://localhost:9400/metrics | grep hygon
```

### 3. 权限问题调试

```bash
# 检查当前用户权限
id

# 检查hy-smi权限
ls -la $(which hy-smi)

# 尝试以root运行hy-smi
sudo hy-smi

# 添加用户到hygon组（如果存在）
sudo usermod -a -G hygon $USER

# 重新登录或刷新组权限
newgrp hygon
```

### 4. 网络和端口调试

```bash
# 检查端口占用
netstat -tlnp | grep 9400

# 检查防火墙
sudo iptables -L | grep 9400

# 使用不同端口测试
./dcgm-exporter-hygon --use-hygon-mode --address=":9401"
```

## 📊 指标验证

### 1. 验证hy-smi输出

```bash
# 手动运行hy-smi查看输出格式
hy-smi

# 检查输出是否包含预期字段
hy-smi | grep -E "DCU|Temp|AvgPwr|Perf|PwrCap|VRAM|Mode"
```

### 2. 验证Prometheus指标

```bash
# 检查指标格式
curl -s http://localhost:9400/metrics | head -20

# 验证海光DCU指标
curl -s http://localhost:9400/metrics | grep "hygon_temperature"
curl -s http://localhost:9400/metrics | grep "hygon_avg_power"
curl -s http://localhost:9400/metrics | grep "hygon_dcu_usage"

# 检查指标标签
curl -s http://localhost:9400/metrics | grep hygon | head -5
```

### 3. 验证指标数值

```bash
# 比较hy-smi和exporter的数值
echo "=== hy-smi 输出 ==="
hy-smi

echo "=== Exporter 指标 ==="
curl -s http://localhost:9400/metrics | grep hygon_temperature
```

## 🔍 常见问题排查

### 1. hy-smi命令未找到

```bash
# 检查PATH
echo $PATH

# 查找hy-smi
find /usr -name "hy-smi" 2>/dev/null
find /opt -name "hy-smi" 2>/dev/null

# 如果找到，添加到PATH或使用完整路径
export PATH=$PATH:/path/to/hy-smi/directory
# 或
./dcgm-exporter-hygon --use-hygon-mode --hy-smi-path="/full/path/to/hy-smi"
```

### 2. 权限被拒绝

```bash
# 检查SELinux状态
getenforce

# 临时禁用SELinux（仅用于测试）
sudo setenforce 0

# 检查AppArmor（Ubuntu）
sudo aa-status

# 使用sudo运行（临时解决方案）
sudo ./dcgm-exporter-hygon --use-hygon-mode
```

### 3. 没有检测到设备

```bash
# 检查海光DCU设备
lspci | grep -i hygon

# 检查驱动模块
lsmod | grep hygon

# 检查设备文件
ls -la /dev/ | grep hygon

# 重新加载驱动（如果需要）
sudo modprobe hygon_driver  # 替换为实际驱动名
```

### 4. 指标数据异常

```bash
# 启用详细日志
./dcgm-exporter-hygon --use-hygon-mode --debug 2>&1 | tee debug.log

# 检查日志中的错误
grep -i error debug.log
grep -i warning debug.log

# 检查hy-smi输出解析
grep "parseHySmiOutput" debug.log
```

## 📝 日志分析

### 1. 启用详细日志

```bash
# 使用调试模式
./dcgm-exporter-hygon --use-hygon-mode --debug

# 重定向日志到文件
./dcgm-exporter-hygon --use-hygon-mode --debug > exporter.log 2>&1

# 实时查看日志
tail -f exporter.log
```

### 2. 关键日志信息

查找以下关键信息：
- `Starting dcgm-exporter in Hygon DCU mode`
- `hy-smi is available and accessible`
- `Hygon collector initialized`
- `Failed to parse device line`
- `Failed to run hy-smi`

### 3. 性能监控

```bash
# 监控CPU和内存使用
top -p $(pgrep dcgm-exporter-hygon)

# 监控网络连接
netstat -tlnp | grep dcgm-exporter-hygon

# 监控文件描述符
lsof -p $(pgrep dcgm-exporter-hygon)
```

## 🧪 测试脚本

创建测试脚本 `test-hygon.sh`：

```bash
#!/bin/bash

echo "=== 海光DCU DCGM Exporter 测试 ==="

# 1. 检查hy-smi
echo "1. 检查hy-smi..."
if command -v hy-smi &> /dev/null; then
    echo "✓ hy-smi 可用"
    hy-smi | head -10
else
    echo "✗ hy-smi 不可用"
    exit 1
fi

# 2. 启动exporter（后台）
echo "2. 启动exporter..."
./dcgm-exporter-hygon --use-hygon-mode --debug &
EXPORTER_PID=$!
sleep 5

# 3. 检查进程
if ps -p $EXPORTER_PID > /dev/null; then
    echo "✓ Exporter 进程运行中 (PID: $EXPORTER_PID)"
else
    echo "✗ Exporter 进程启动失败"
    exit 1
fi

# 4. 检查端口
if netstat -tlnp | grep :9400 > /dev/null; then
    echo "✓ 端口 9400 监听中"
else
    echo "✗ 端口 9400 未监听"
fi

# 5. 检查指标
echo "3. 检查指标..."
METRICS=$(curl -s http://localhost:9400/metrics)
if echo "$METRICS" | grep "hygon_temperature" > /dev/null; then
    echo "✓ 海光DCU指标可用"
    echo "$METRICS" | grep hygon | head -5
else
    echo "✗ 海光DCU指标不可用"
fi

# 6. 清理
echo "4. 清理..."
kill $EXPORTER_PID
echo "测试完成"
```

## 📞 获取帮助

如果遇到问题，请收集以下信息：

1. **系统信息**：`uname -a`
2. **hy-smi输出**：`hy-smi`
3. **错误日志**：完整的错误信息
4. **配置信息**：使用的命令行参数
5. **环境变量**：相关的环境变量设置

然后可以：
- 查看项目文档
- 提交Issue到项目仓库
- 联系技术支持
