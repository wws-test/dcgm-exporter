# OS - wrapper package for system os package

The package allows to mock os package functions for testing purposes.


